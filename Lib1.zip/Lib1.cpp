--------------------(headSHOT-----------------
Patches.headShot = MemoryPatch("libil2cpp.so",11055308 , "\x13\x00\xA0\xE3\1E\FF\2F\E1", 8);
MemoryPatch("libil2cpp.so", 0x30667008,"\x10\x00\xA0\xE3\x1E\xFF\x2F\xE1", 8);
--------------------(recargaRapida-----------------
Patches.recargaRapida = MemoryPatch("libil2cpp.so",11055308 , "\x12\x03\xA0\xE3\1E\FF\2F\E1", 8);(\\\"restore\\\")\", \"/data/app/com.dts.freefireth-HGYrjXW6ifcG3KFLnLR87w==/lib/arm/");